from flask import Flask, render_template, request, abort
from modelo.models import db
from modelo.models import Alumno, Categoria
#from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__)
#db=SQLAlchemy()
app.config['SQLALCHEMY_DATABASE_URI']='mysql+pymysql://programmerpancho_user:hola.123@localhost/ProgrammerPancho'
app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = True
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False

#Rutas de acceso al sistema
@app.route('/')
def inicio():
    return render_template('login.html')

@app.route('/login')
def login():
    usuario = 'Yoryii'
    return render_template('principal.html', user = usuario)

#Fin de rutas de acceso al sistema

@app.route('/principal')
def principal():
    return render_template('principal.html')

'''Ruta dinamica
@app.route('/eliminarCategoria/<idCategoria>')
def eliminarCategoria(idCategoria):
    return 'Eliminando la categoria ' + idCategoria'''

#CRUD Alumnos
@app.route('/alumnos/new')
def nuevoAlumno():
    return render_template('Alumnos/altaAlumno.html')
@app.route('/alumnos/edit')
def editarAlumno():
    return render_template('Alumnos/editarAlumno.html')
@app.route('/alumnos/delete')
def eliminarAlumno():
    return render_template('Alumnos/eliminarAlumno.html')
@app.route('/alumnos')
def consultarAlumno():
    return render_template('Alumnos/consultaAlumnos.html')
@app.route('/alumnos/save', methods=['POST'])
def agregarAlumno():
    try:
        a=Alumno()
        a.noControl=request.form['noControl']
        a.idUsuario=request.form['idUsuario']
        a.idCarrera=request.form['idCarrera']
        a.semestre=request.form['semestre']
        a.insertar()
        return 'Edificio registrado con exito'
    except:
        return 'Error al registrar al alumno'

#Fin CRUD Alumnos

#CRUD Categorias
@app.route('/categorias/new')
def nuevaCategoria():
    return render_template('Categorias/creaciónCategoria.html')
@app.route('/categorias/edit')
def editarCategoria():
    return render_template('Categorias/editarCategoria.html')
@app.route('/categorias/delete')
def eliminarCategoria():
    return render_template('Categorias/eliminarCategoria.html')
@app.route('/categorias')
def consultarCategoria():
    return render_template('Categorias/consultaCategorias.html')
@app.route('/categorias/save', methods=['POST'])
def agregarCategoria():
    try:
        c=Categoria()
        c.nombre=request.form['nombre']
        c.limiteSemestre=request.form['limiteSemestre']
        c.insertar()
        return 'Guardado'
    except:
        return 'error'

#Fin CRUD Categorias

#CRUD Equipos
@app.route('/equipos/new')
def nuevoEquipo():
    return render_template('Equipos/creaciónEquipo.html')
@app.route('/equipos/edit')
def editarEquipo():
    return render_template('Equipos/editarEquipo.html')
@app.route('/equipos/delete')
def eliminarEquipo():
    return render_template('Equipos/eliminarEquipo.html')
@app.route('/equipos')
def consultarEquipo():
    return render_template('Equipos/consultaEquipos.html')

#Terminan CRUD

@app.errorhandler(404)
def error_404(e):
    return render_template('Errores/error_404.html'), 404

@app.errorhandler(500)
def error_500(e):
    return render_template('Errores/error_500.html'), 500

if __name__=='__main__':
    db.init_app(app)
    app.run(debug=True)